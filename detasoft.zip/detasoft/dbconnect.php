<?php 
// isi nama host, username mysql, dan password mysql anda
$conn = mysqli_connect("localhost","root","","detasoft"); //berfungsi untuk memanggil database

if(!$conn){
	echo "gagal konek database menn";
} else {
	
};

?>